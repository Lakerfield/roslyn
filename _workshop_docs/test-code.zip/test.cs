﻿using System;
using System.Collections.Generic;

int ReadInt(string s)
{
    Console.Write(s + ": ");
    return int.Parse(Console.ReadLine());
}

//bool b = 5 in 0..10;
//bool b = ReadInt("x") in ReadInt("start")..ReadInt("end");
//bool b = 'i' in "Michael";

//bool b = ReadInt("x") in new[] { ReadInt("start"), ReadInt("end") };

bool b = 3 in new List<int>();
//bool b = 3 in new List<int>(1, 2, 3, 4);


Console.WriteLine(b);


class X
{

    public bool Contains(int x) { return true; }
}


